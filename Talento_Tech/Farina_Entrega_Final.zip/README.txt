Hola Profe.

Esta app corre ejecutando desde Visual Studio Code o desde la linea de comando.
No esta realizada en Colab o Jupiter.

Ejecutando el archivo EF_Entrega_Final.py se abre automaticamente la base de datos.
A la misma le puse el nombre productos.db.

Es una app de tkinter. Es grafica. Me inspire en tu curso y me apoye mucho en ChatGPT y StackOverFlow.

Para borrar un item se debe primero seleccionar el mismo y despues borrar.

Para editar un item, primero se debe seleccionar, luego editar y finalmente actualizar.

Pensaba poner un menu de ayuda en el futuro. Pero es bastante intuitiva.

Para guardar los datos hay que poner guardar en db.

Muchas Gracias por todo tu apoyo y didactica durante el curso.

Espero armen un curso de python intermedio, avanzado para ver bien lo de las clases.
Eso me cuesta bastante.

Saludos,
Eduardo.

